#!/bin/sh
# /opt/autosave.sh
# Nil OS AutoSave Script - every 2 minutes

ROOT_DEV=$(mount | grep 'on / ' | awk '{print $1}')
PERSISTENT=$(lsblk -no MOUNTPOINT $ROOT_DEV)/tce
mkdir -p "$PERSISTENT"
export TCE_DIR="$PERSISTENT"

filetool.sh -r

while true; do
    find / -mindepth 1 > /opt/.filetool.lst
    
    filetool.sh -b
    
    sleep 120
done &

