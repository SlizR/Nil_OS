#!/bin/sh
# /opt/bootlocal.sh
# Nil OS OTA Updater
# Nil OS Disk Save Script

/opt/welcome.sh
/opt/autosave.sh

ROOT_DEV=$(mount | grep 'on / ' | awk '{print $1}')
PERSISTENT=$(lsblk -no MOUNTPOINT $ROOT_DEV)/tce
mkdir -p "$PERSISTENT"
export TCE_DIR="$PERSISTENT"

filetool.sh -r

find / -mindepth 1 > /opt/.filetool.lst
filetool.sh -b

while true; do
    /opt/ota.sh
    find / -mindepth 1 > /opt/.filetool.lst
    filetool.sh -b
    sleep 86400
done &
