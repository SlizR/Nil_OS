#!/bin/sh

JSON_URL="https://raw.githubusercontent.com/SlizR/Nil_OS/main/update.json"
TMP_DIR="/tmp/ota"
ISO_FILE="$TMP_DIR/update.iso"
MOUNT_DIR="$TMP_DIR/mount"

mkdir -p "$TMP_DIR"
mkdir -p "$MOUNT_DIR"

LATEST_VERSION=$(wget -qO- "$JSON_URL" | grep '"version":' | head -n1 | cut -d'"' -f4)
ISO_URL=$(wget -qO- "$JSON_URL" | grep '"url":' | head -n1 | cut -d'"' -f4)

CURRENT_VERSION=$(grep VERSION= /etc/os-release | cut -d'"' -f2)

echo "Now version: $CURRENT_VERSION, latest version: $LATEST_VERSION"

if [ "$LATEST_VERSION" = "$CURRENT_VERSION" ]; then
    echo "System already updated."
    exit 0
fi

echo "Download ISO $ISO_URL..."
wget -O "$ISO_FILE" "$ISO_URL"

mount -o loop "$ISO_FILE" "$MOUNT_DIR"

echo "Apply updates..."
rsync -avu --delete "$MOUNT_DIR/" "/"

umount "$MOUNT_DIR"
rm -rf "$MOUNT_DIR" "$ISO_FILE"

filetool.sh -b

echo "Update complete, reboot..."
reboot

