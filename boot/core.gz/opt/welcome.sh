#!/bin/sh

BOOT_TIME_SEC=$(awk '{printf "%.3f",$1}' /proc/uptime)
BOOT_TIME_MS=$(awk "BEGIN {printf \"%d\", $BOOT_TIME_SEC * 1000}")

USERNAME=${USER:-$(whoami)}

ROWS=$(tput lines)
COLS=$(tput cols)

LOGO_0=" _   _   _          ____   ____      "
LOGO_1="| \ | (_) |        |  _ \ | ___|     "
LOGO_2="|  \| | | |        | | | ||___ \\    "
LOGO_3="| |\  | | |___     | |_| | ___) |    "
LOGO_4="|_| \_|_|_____|    |____/ |____/     "

FINAL_LOGO_0=" _   _   _     "
FINAL_LOGO_1="| \ | (_) |    "
FINAL_LOGO_2="|  \| | | |    "
FINAL_LOGO_3="| |\  | | |___ "
FINAL_LOGO_4="|_| \_|_|_____|"

shift_logo() {
    line="$1"
    shift_amount=$2
    len=$(echo -n "$line" | wc -c)
    shift_mod=$(expr $shift_amount % $len)
    left=$(echo -n "$line" | cut -c$((shift_mod + 1))-$len)
    right=$(echo -n "$line" | cut -c1-$shift_mod)
    echo "$left$right"
}

t=0
while [ $t -lt 30 ]; do
    clear
    ROW_START=$(expr \( $ROWS - 5 \) / 2)
    COL_START=$(expr \( $COLS - 38 \) / 2)

    j=0
    while [ $j -le 4 ]; do
        tput cup $(expr $ROW_START + $j) $COL_START
        eval line=\$LOGO_$j
        shift_logo "$line" $t
        j=$(expr $j + 1)
    done

    sleep 0.05
    t=$(expr $t + 1)
done

clear
ROW_START=$(expr \( $ROWS - 5 \) / 2)
COL_START=$(expr \( $COLS - 7 \) / 2)

j=0
while [ $j -le 4 ]; do
    tput cup $(expr $ROW_START + $j) $COL_START
    eval echo \$FINAL_LOGO_$j
    j=$(expr $j + 1)
done

MSG="Nil OS Welcome, $USERNAME!"
tput cup $(expr $ROW_START + 6) $(expr \( $COLS - ${#MSG} \) / 2)
echo "$MSG"

MSG2="Load: $BOOT_TIME_MS ms"
tput cup $(expr $ROW_START + 7) $(expr \( $COLS - ${#MSG2} \) / 2)
echo "$MSG2"

sleep 6
clear
